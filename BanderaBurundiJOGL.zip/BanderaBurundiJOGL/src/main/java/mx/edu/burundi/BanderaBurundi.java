package mx.edu.burundi;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Clase principal del proyecto. */
public final class BanderaBurundi {
    private BanderaBurundi() { }
    private static void mostrar() {
        JFrame ventana=new JFrame("Bandera de Burundi · Java con JOGL");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel contenido=new JPanel(new BorderLayout(0,24));
        contenido.setBackground(Color.WHITE);
        contenido.setBorder(new EmptyBorder(28,32,28,32));
        JLabel titulo=new JLabel("Bandera de Burundi");
        titulo.setFont(new Font("SansSerif",Font.BOLD,30));
        titulo.setForeground(new Color(0x0756A3));
        contenido.add(titulo,BorderLayout.NORTH);
        JPanel marco=new JPanel(new BorderLayout());
        marco.setBackground(Color.WHITE);
        marco.setBorder(BorderFactory.createLineBorder(new Color(0xF0F5FD),6));
        marco.add(new PanelBandera(),BorderLayout.CENTER);
        contenido.add(marco,BorderLayout.CENTER);
        ventana.setContentPane(contenido);
        ventana.setMinimumSize(new Dimension(570,400));
        ventana.pack();ventana.setLocationRelativeTo(null);ventana.setVisible(true);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { mostrar(); }
            catch(Throwable ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null,"No se pudo iniciar JOGL.\n"+ex.getMessage(),
                    "Error al iniciar",JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
