package mx.edu.burundi;

import java.util.ArrayList;
import java.util.List;

/** Figuras vectoriales en coordenadas 0..5 (ancho) y 0..3 (alto). */
public final class GeometriaBandera {
    public static final int ROJO = 0xCE092F;
    public static final int VERDE = 0x43B022;
    public static final int BLANCO = 0xFFFFFF;
    public record Punto(double x, double y) { }
    public record Triangulo(int color, Punto a, Punto b, Punto c) { }
    private GeometriaBandera() { }

    public static List<Triangulo> crear() {
        List<Triangulo> figuras = new ArrayList<>();
        // Cuatro campos: superior e inferior rojos; laterales verdes.
        triangulo(figuras, ROJO, 0,3, 5,3, 2.5,1.5);
        triangulo(figuras, ROJO, 0,0, 5,0, 2.5,1.5);
        triangulo(figuras, VERDE, 0,0, 0,3, 2.5,1.5);
        triangulo(figuras, VERDE, 5,0, 5,3, 2.5,1.5);
        // Dos bandas diagonales blancas, recortadas a los bordes de la bandera.
        poligonoConvexo(figuras, BLANCO, new double[][]{
            {0,0},{.39,0},{5,2.766},{5,3},{4.61,3},{0,.234}});
        poligonoConvexo(figuras, BLANCO, new double[][]{
            {0,3},{.39,3},{5,.234},{5,0},{4.61,0},{0,2.766}});
        // Disco central blanco, con radio proporcional a la imagen de referencia.
        circulo(figuras, 2.5,1.5,.85);
        // Una estrella arriba y dos abajo, todas con seis puntas.
        estrellaBorde(figuras,2.5,1.94);
        estrellaBorde(figuras,2.12,1.28);
        estrellaBorde(figuras,2.88,1.28);
        return List.copyOf(figuras);
    }
    private static void triangulo(List<Triangulo> t,int color,double ax,double ay,double bx,double by,double cx,double cy) {
        t.add(new Triangulo(color,new Punto(ax,ay),new Punto(bx,by),new Punto(cx,cy)));
    }
    private static void poligonoConvexo(List<Triangulo> t,int color,double[][] p) {
        for(int i=1;i<p.length-1;i++)
            triangulo(t,color,p[0][0],p[0][1],p[i][0],p[i][1],p[i+1][0],p[i+1][1]);
    }
    private static void circulo(List<Triangulo> t,double cx,double cy,double radio) {
        int segmentos=360;
        for(int i=0;i<segmentos;i++) {
            double a=2*Math.PI*i/segmentos,b=2*Math.PI*(i+1)/segmentos;
            triangulo(t,BLANCO,cx,cy,cx+radio*Math.cos(a),cy+radio*Math.sin(a),cx+radio*Math.cos(b),cy+radio*Math.sin(b));
        }
    }
    private static void estrellaBorde(List<Triangulo> t,double cx,double cy) {
        estrella(t,VERDE,cx,cy,.200);
        estrella(t,ROJO,cx,cy,.164);
    }
    private static void estrella(List<Triangulo> t,int color,double cx,double cy,double radio) {
        // Doce vértices alternados: seis exteriores y seis interiores.
        // Seis puntas, no la estrella habitual de cinco puntas.
        Punto[] puntos=new Punto[12];
        for(int i=0;i<12;i++) {
            double angulo=Math.PI/2+i*Math.PI/6;
            double r=i%2==0?radio:radio/Math.sqrt(3);
            puntos[i]=new Punto(cx+r*Math.cos(angulo),cy+r*Math.sin(angulo));
        }
        for(int i=0;i<12;i++) {
            Punto a=puntos[i],b=puntos[(i+1)%12];
            triangulo(t,color,cx,cy,a.x(),a.y(),b.x(),b.y());
        }
    }
}
