package mx.edu.burundi;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLJPanel;
import java.awt.Dimension;
import java.util.List;

/** Dibujo realizado íntegramente con primitivas OpenGL a través de JOGL. */
public final class PanelBandera extends GLJPanel implements GLEventListener {
    private static final long serialVersionUID = 1L;
    private final List<GeometriaBandera.Triangulo> figuras=GeometriaBandera.crear();
    public PanelBandera() {
        super(new GLCapabilities(GLProfile.get(GLProfile.GL2)));
        setPreferredSize(new Dimension(870,522));
        addGLEventListener(this);
    }
    @Override public void init(GLAutoDrawable d) {
        GL2 gl=d.getGL().getGL2();
        gl.glDisable(GL.GL_DEPTH_TEST);
        gl.glDisable(GL.GL_CULL_FACE);
        gl.glClearColor(1,1,1,1);
    }
    @Override public void dispose(GLAutoDrawable d) { }
    @Override public void reshape(GLAutoDrawable d,int x,int y,int w,int h) { }
    @Override public void display(GLAutoDrawable d) {
        GL2 gl=d.getGL().getGL2();
        int ancho=Math.max(1,d.getSurfaceWidth()),alto=Math.max(1,d.getSurfaceHeight());
        gl.glClear(GL.GL_COLOR_BUFFER_BIT);
        // Mantener la proporción 5:3 al redimensionar; centrar la bandera.
        int[] area=areaDibujo(ancho,alto);
        gl.glViewport(area[0],area[1],area[2],area[3]);
        gl.glMatrixMode(GL2.GL_PROJECTION);gl.glLoadIdentity();
        gl.glOrtho(0,5,0,3,-1,1);
        gl.glMatrixMode(GL2.GL_MODELVIEW);gl.glLoadIdentity();
        gl.glBegin(GL2.GL_TRIANGLES);
        for(GeometriaBandera.Triangulo t:figuras) {
            int color=t.color();
            gl.glColor3f(((color>>16)&255)/255f,((color>>8)&255)/255f,(color&255)/255f);
            gl.glVertex2d(t.a().x(),t.a().y());
            gl.glVertex2d(t.b().x(),t.b().y());
            gl.glVertex2d(t.c().x(),t.c().y());
        }
        gl.glEnd();gl.glFlush();
    }
    static int[] areaDibujo(int ancho,int alto) {
        double escala=Math.min(ancho/5.0,alto/3.0);
        int w=Math.max(1,(int)Math.round(escala*5));
        int h=Math.max(1,(int)Math.round(escala*3));
        return new int[]{(ancho-w)/2,(alto-h)/2,w,h};
    }
}
